package com.ptrprograms.customdrawablestates;

/**
 * Created by paulruiz on 1/11/15.
 */
public enum CustomState {
    GO,
    SLOW_DOWN,
    STOP
}
