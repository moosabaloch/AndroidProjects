package com.ptrprograms.eventdrivenhierarchicalviews.model;

/**
 * Created by paulruiz on 12/9/14.
 */
public enum WeatherCondition {
    RAIN,
    SNOW,
    LIGHTNING,
    SUN,
    CLOUDY,
    FOG
}
