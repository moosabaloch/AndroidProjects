package com.ptrprograms.eventdrivenhierarchicalviews.util;

import com.ptrprograms.eventdrivenhierarchicalviews.model.Weather;

/**
 * Created by paulruiz on 12/9/14.
 */
public interface Updateable {
    public void update( Weather weather );
}
