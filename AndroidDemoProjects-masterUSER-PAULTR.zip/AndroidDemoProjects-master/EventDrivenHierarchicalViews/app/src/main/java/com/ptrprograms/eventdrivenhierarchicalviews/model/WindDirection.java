package com.ptrprograms.eventdrivenhierarchicalviews.model;

/**
 * Created by paulruiz on 12/9/14.
 */
public enum WindDirection {
    N,
    NE,
    E,
    SE,
    S,
    SW,
    W,
    NW
}
