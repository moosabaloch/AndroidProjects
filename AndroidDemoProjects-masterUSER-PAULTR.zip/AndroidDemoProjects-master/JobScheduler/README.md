### Tuts+ article: Using the Android JobScheduler

### Instructor: Paul Trebilcox-Ruiz

The JobScheduler API was introduced in Android Lollipop, and is used for batching and scheduling future tasks that run in the background of the device when certain conditions are met. 

Available March 2015 on TutsPlus.com
