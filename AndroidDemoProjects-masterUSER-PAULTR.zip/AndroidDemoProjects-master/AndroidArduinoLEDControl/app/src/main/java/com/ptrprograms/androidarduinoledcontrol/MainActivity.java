package com.ptrprograms.androidarduinoledcontrol;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Paul Trebilcox-Ruiz on 7/27/14.
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
    }
}
