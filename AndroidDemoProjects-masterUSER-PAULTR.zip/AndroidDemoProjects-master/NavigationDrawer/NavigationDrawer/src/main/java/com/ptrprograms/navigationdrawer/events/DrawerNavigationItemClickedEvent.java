package com.ptrprograms.navigationdrawer.events;

/**
 * Created by PaulTR on 5/12/14.
 */
public class DrawerNavigationItemClickedEvent {

	public String section;

	public DrawerNavigationItemClickedEvent( String section ) {
		this.section = section;
	}

}
