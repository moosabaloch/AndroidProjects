package com.cloudinary.test;

public class ApiTest extends AbstractApiTest {
}
