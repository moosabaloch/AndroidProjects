package com.cloudinary.utils;

public class Rectangle {

	public int height;
	public int width;
	public int y;
	public int x;

	public Rectangle(int x, int y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width= width;
		this.height= height;
	}

}
